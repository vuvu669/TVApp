#!/system/bin/sh
# Run service in background at early boot
/data/adb/modules/tvs_systemui_mod/service.sh &
