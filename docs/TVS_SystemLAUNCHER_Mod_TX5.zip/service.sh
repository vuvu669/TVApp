#!/system/bin/sh
# TVS SystemUI Mod - By Tony Vũ
# Xóa Google TV Launcher systemless mỗi boot
# và chỉ cài Giaodien.apk nếu chưa có trong system

SLEEP=10
sleep $SLEEP

MOD_DIR="/data/adb/modules/tvs_systemui_mod"
MOD_MOUNT="/data/adb/modules_mount"
APP_DST="/system/priv-app/Giaodien"
APP_SRC="$MOD_DIR/system/priv-app/Giaodien/Giaodien.apk"

echo "🗑️ Đang xử lý systemless Google TV Launcher..."

# ---------- GỠ SYSTEMLESS GOOGLE TV LAUNCHER MỖI LẦN BOOT ----------
LAUNCHER_PATHS="
/system/priv-app/TVLauncherXPrebuilt
/system/priv-app/TvLauncher
/system/priv-app/GoogleTvLauncher
/system/priv-app/com.google.android.tvlauncher
/system/priv-app/com.google.android.apps.tv.launcherx
"

for path in $LAUNCHER_PATHS; do
  if [ -d "$path" ]; then
    echo "🧹 Xóa $path ..."
    rm -rf "$path" 2>/dev/null || true
    touch "$path/.replace" 2>/dev/null || true
  fi
done

# Xóa overlay trong modules_mount nếu có
if [ -d "$MOD_MOUNT" ]; then
  find "$MOD_MOUNT" -type d -path "*/TVLauncherXPrebuilt*" -exec rm -rf {} + 2>/dev/null
  find "$MOD_MOUNT" -type d -path "*/GoogleTvLauncher*" -exec rm -rf {} + 2>/dev/null
fi

echo "✅ Đã xử lý xong Google TV Launcher systemless."

# ---------- KIỂM TRA VÀ CÀI GIAO DIỆN ----------
echo "🔍 Kiểm tra Giaodien.apk trong system..."
if [ -f "$APP_DST/Giaodien.apk" ]; then
  echo "✅ Đã có sẵn Giaodien.apk trong system, bỏ qua cài đặt."
else
  if [ -f "$APP_SRC" ]; then
    echo "📦 Cài Giaodien.apk vào $APP_DST ..."
    mkdir -p "$APP_DST" 2>/dev/null || true
    cp -f "$APP_SRC" "$APP_DST/Giaodien.apk" 2>/dev/null || true
    chown 0:0 "$APP_DST/Giaodien.apk" 2>/dev/null || true
    chmod 0644 "$APP_DST/Giaodien.apk" 2>/dev/null || true
    chown 0:0 "$APP_DST" 2>/dev/null || true
    chmod 0755 "$APP_DST" 2>/dev/null || true
    if command -v restorecon >/dev/null 2>&1; then
      restorecon -R "$APP_DST" 2>/dev/null || true
    fi
    echo "✅ Đã cài đặt Giaodien.apk vào system/priv-app/Giaodien/"
  else
    echo "⚠️ Không tìm thấy Giaodien.apk trong module!"
  fi
fi

exit 0
