#!/system/bin/sh
# TVS Remove Google TV Launcher - By Tony Vũ
# Xóa đúng thư mục TVLauncherXPrebuilt (systemless) mỗi lần boot

SLEEP=10
sleep $SLEEP

TARGET_PATH="/system/priv-app/TVLauncherXPrebuilt"
MOD_MOUNT="/data/adb/modules_mount"

echo "🗑️ Xóa Google TV Launcher systemless..."

# Xóa thư mục system launcher
if [ -d "$TARGET_PATH" ]; then
  echo "🧹 Đang xóa $TARGET_PATH ..."
  rm -rf "$TARGET_PATH" 2>/dev/null || true
  touch "$TARGET_PATH/.replace" 2>/dev/null || true
fi

# Xóa nếu có overlay trong modules_mount (trường hợp systemless)
if [ -d "$MOD_MOUNT" ]; then
  find "$MOD_MOUNT" -type d -path "*/TVLauncherXPrebuilt*" -exec rm -rf {} + 2>/dev/null
fi

echo "✅ Đã xử lý xong Google TV Launcher systemless."
exit 0
