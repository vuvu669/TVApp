#!/system/bin/sh
# Chạy service.sh nền mỗi khi boot
/data/adb/modules/tvs_remove_gtvlauncher/service.sh &
